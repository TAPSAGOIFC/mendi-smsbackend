
const express = require('express');
const bodyParser = require('body-parser');
const africastalking = require('africastalking');

const app = express();
app.use(bodyParser.json());

// Replace with your Africa's Talking credentials
const at = africastalking({
    apiKey: process.env.AT_API_KEY,     // Set this in environment variables
    username: process.env.AT_USERNAME   // Usually 'sandbox' or your username
});

const sms = at.SMS;

app.post('/send-code', async (req, res) => {
    const { phone, code, sender } = req.body;
    try {
        const result = await sms.send({
            to: [phone],
            message: `A verification code has been sent to you (Code: ${code})`,
            from: sender
        });
        res.json({ success: true, result });
    } catch (error) {
        console.error("SMS send error:", error);
        res.status(500).json({ success: false, error: error.message });
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log("MENDI SMS backend running on port", PORT));
